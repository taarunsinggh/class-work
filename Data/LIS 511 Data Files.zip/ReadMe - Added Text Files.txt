The following are some text copies of famous documents that I added for your use, if you want. Feel free to add your own. Be sure they are text files not PDF or Word documents.

�  95Theses.txt � Germany English translation of Martin Luther's �Disputation on the Power and Efficacy of Indulgences,� also known as �The 95 Theses,�
�  DoI.txt � US Declaration of Independence
�  BoR.txt � US Original Bill of Rights
�  BoR-Full.txt � US Bill of Rights with all Amendments
�  Constitution.txt � US Constitution
�  Gettysburg.txt � US President Lincoln's Gettysburg Address
�  MagnaCarta.txt � England 1215 (English translation)
�  Margaritaville.txt � Lyrics by Jimmy Buffett
�  UDHR.txt � UN The Universal Declaration of Human Rights

�  Romeo and Juliet.txt - Act 2, Scene II. Capulet's orchard.

Hope you find these interesting.

Bob
